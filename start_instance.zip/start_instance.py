import boto3
import os


def start_instances(region):
    client = boto3.client('ec2', region_name=region)
    startList = []
    custom_filter = [{
        'Name': 'tag:' + os.environ["SchedulerTagName"],
        'Values': [os.environ["SchedulerTagValue"]]
    }]

    # Get instance instance with tag: custom_filter
    response = client.describe_instances(Filters=custom_filter)
    # Append filtered instance with state stopped to "startList"
    if response['Reservations']:
        for instance in response['Reservations'][0]['Instances']:
            if instance['State']['Name'] == "stopped":
                startList.append(instance['InstanceId'])
        if startList:
            print("Starting instance: " + ", ".join(startList) + "in region: " + region)
            response = client.start_instances(
                InstanceIds=startList
            )
    else:
        print("No instances with tag {} in region {}".format(
            os.environ["SchedulerTagName"], region))

def lambda_handler(event, context):
    # Get all regions availables
    ec2 = boto3.client('ec2')
    regions = ec2.describe_regions()

    # iter regions
    for region in regions['Regions']:
        
        region_name = region['RegionName']
        print("Region: " + region_name)
        start_instances(region_name)

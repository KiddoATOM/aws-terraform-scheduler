import boto3
import os


ACCOUNT_ID = boto3.client('sts').get_caller_identity().get('Account')


def remove_images_from_ecr_repo(repositories, region):
    ecr_client = boto3.client('ecr', region_name=region)                                           
                                   
    for repositorie in repositories:
        images = []
        repositorie = repositorie.strip()
        try:
            response = ecr_client.list_images(
                registryId=ACCOUNT_ID,
                repositoryName=repositorie,
                maxResults=1000
            )
        except ecr_client.exceptions.RepositoryNotFoundException:
            print("No repository of the list {} was found in the {} region".format(
                repositories, region))
        else:
            images = response['imageIds']
        
        print("Removing all images of the repositorie {} in region {}".format(
                repositori, region))
        for image in images:
            delete_response = ecr_client.batch_delete_image(
                registryId=ACCOUNT_ID,
                repositoryName=repositorie,
                imageIds=[
                    {
                        'imageDigest': image['imageDigest'],
                    },
                ]
            )


def stop_instances(region):
    client = boto3.client('ec2', region_name=region)

    stopList = []

    custom_filter = [{
        'Name': 'tag:' + os.environ["SchedulerTagName"],
        'Values': [os.environ["SchedulerTagValue"]]}]

    # Get instance instance with tag: custom_filter
    response = client.describe_instances(Filters=custom_filter)
    # Append filtered instance with state stopped to "stopList"
    if response['Reservations']:
        for instance in response['Reservations'][0]['Instances']:
            if instance['State']['Name'] == "running":
                stopList.append(instance['InstanceId'])
        if stopList:
            print("Stopping instance: " + ", ".join(stopList) + "in region: " + region)
            response = client.stop_instances(
                InstanceIds=stopList
            )


def remove_objects_from_bucket(buckets):
    s3 = boto3.resource('s3')                                           
                                   
    for bucket_name in buckets:
        try:
            bucket = s3.Bucket(bucket_name)
        except:
            pass
        else:
            print("Removing all objects from the bucket {}".format(
                os.environ["Buckets"]))
            bucket.objects.all().delete()


def lambda_handler(event, context):
    # Get all regions availables
    ec2 = boto3.client('ec2')
    # Get all availables regions
    regions = ec2.describe_regions()

    repositories = os.environ["Repositories"]
    repositories = repositories.split(",")

    buckets = os.environ["Buckets"]
    buckets = buckets.split(",")

    # iter regions
    for region in regions['Regions']:
        region_name = region['RegionName']
        print("Region: " + region_name)
        
        print("Stopping all instances with tag {} in region {}".format(
            os.environ["SchedulerTagName"], region_name))
        stop_instances(region_name)
        
        if os.environ['Repositories']:
            remove_images_from_ecr_repo(repositories, region_name)

    if os.environ['Buckets']:
        remove_objects_from_bucket(buckets)

